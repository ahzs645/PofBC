// Writes public/capabilities.json: what this generator can make, in one fetch.
//
// An agent arriving at the site would otherwise have to infer the option space by reading the DOM
// — which layouts exist, which formats the browser will encode, what a ministry name may contain.
// This states it outright, and states it in the vocabulary the URL and the WebMCP tools use, so a
// value read from here can be passed straight back in.
//
// Generated rather than written by hand, and from the same constants the application imports, so
// the manifest cannot drift from the thing it describes. Adding a lockup updates it for free.
//
// Run: npm run build:capabilities

import { mkdirSync, readFileSync, writeFileSync } from 'node:fs'
import { dirname, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'

import {
  CLEAR_SPACE, CLEAR_SPACE_ORDER, LAYOUTS, LAYOUT_ORDER, MARK_ALIGNMENTS, MARK_ALIGNMENT_ORDER,
  MARK_BOX, PROVINCE_WORDMARK, defaultMarkAlignment
} from '../src/logo/layouts.js'
import { BRAND_COLORS, TRANSPARENT } from '../src/logo/logoColors.js'
import { EXPORT_FORMATS, EXPORT_FORMAT_ORDER, SIZE_PRESETS } from '../src/export/exportLogo.js'
import { MINISTRY_GROUPS, MINISTRY_LIST_REVIEWED } from '../src/ministries/ministries.js'
import { CURRENT_VARIANTS, CURRENT_VARIANT_ORDER, LANGUAGES, LANGUAGE_ORDER, BCID } from '../src/current/currentMarks.js'
import { MINISTRIES as CURRENT_MINISTRIES } from '../src/current/ministries.js'
import { FLAG_PALETTE_ORDER } from '../src/flag/flagPalettes.js'
import { ALL_FLAG_SYMBOLS, FLAG_SYMBOLS, NAME_PLACEMENTS } from '../src/flag/flagLayout.js'
import {
  CREST_ARRANGEMENTS, CREST_PLACEMENTS, MINISTRY_SIZES, MINISTRY_SIZE_ORDER, MINISTRY_STEPS
} from '../src/crest/crestLayout.js'
import { FLAG_PALETTE } from '../src/assets/flagMark.js'
import { SHARE_PARAM } from '../src/site/shareLink.js'
import { CONFIG_PARAM, toConfig } from '../src/site/configFormat.js'
import { DEFAULTS } from '../src/site/lockupDefaults.js'

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..')
const { name, version, description } = JSON.parse(readFileSync(resolve(root, 'package.json'), 'utf8'))

const manifest = {
  name,
  version,
  description,
  documentation: 'https://github.com/ahzs645/PofBC#readme',

  // Two identities, and almost nothing carries between them. Everything below this describes the
  // historical era unless it says otherwise.
  eras: {
    historical: {
      description: 'The crest identity, rebuilt from supplied artwork. Any ministry, any wording, ' +
        'any colour, four lockups. Everything else in this manifest describes this era.',
      generated: true
    },
    flag: {
      description: 'The B.C. Flag Symbol with a ministry set against it. Five arrangements, all ' +
        'of them printed: BC beside the flag or the flag above BC — the two the standards page ' +
        'sanctions — plus the flag alone, each with the wording below the symbol or beside it.',
      generated: true,
      symbols: FLAG_SYMBOLS,
      oneOffs: ALL_FLAG_SYMBOLS.filter((id) => !FLAG_SYMBOLS.includes(id)),
      namePlacements: NAME_PLACEMENTS,
      flagPalettes: FLAG_PALETTE_ORDER,
      colours: {
        official: 'Pantone Blue 072C, Red 032C, Yellow 109C, per the identity’s standards page.',
        supplied: FLAG_PALETTE
      },
      note: 'The standards page gives the symbol and its colours but never a ministry name, so ' +
        'the proportions are measured off printed documents — which disagree with each other. ' +
        'The flag’s white is the page showing through it, so on a coloured ground the whole ' +
        'lockup is set in one ink, as the documents do.'
    },
    crest: {
      description: 'The coat of arms with the BRITISH COLUMBIA wordmark — the identity that ' +
        'followed the flag one. Both are artwork: the arms as drawn, and the wordmark as ' +
        'outlines rather than text, so only the ministry is typeset.',
      generated: true,
      arrangements: CREST_ARRANGEMENTS,
      ministryPlacements: CREST_PLACEMENTS,
      ministrySizes: MINISTRY_SIZE_ORDER.map((id) => ({ id, ofWordmark: MINISTRY_SIZES[id] })),
      secondLineSizes: MINISTRY_STEPS,
      note: 'Proportions are measured off twelve printed documents, each reading checked by ' +
        'aspect first so it is known to be of the same two drawings. They disagree in two ' +
        'places, so both readings are offered rather than averaged: the stacked lockup comes ' +
        'in two proportions, and the ministry in three sizes, a trailing line optionally a ' +
        'step below the ministry above it.'
    },
    current: {
      description: 'The Province’s BC mark, used exactly as published, with the ministry wording ' +
        'set beside it in the same alphabet the published marks are lettered with. Pick a ' +
        'ministry for its official wording, or supply your own for one that has been renamed or ' +
        'never had a mark published.',
      generated: true,
      ministries: CURRENT_MINISTRIES.map(({ code, en, fr }) => ({ code, en, fr })),
      note: 'A newline in the wording is a line break, as in the published artwork: the ' +
        'Province’s marks are broken by hand rather than wrapped to a measure, so the official ' +
        'wording carries the breaks it was published with.',
      languages: LANGUAGE_ORDER.map((id) => ({ id, label: LANGUAGES[id] })),
      variants: CURRENT_VARIANT_ORDER.map((id) => ({
        id,
        label: CURRENT_VARIANTS[id].label,
        description: CURRENT_VARIANTS[id].description
      })),
      palette: BCID
    }
  },

  // The drawing every lockup shares, in the units every measurement below is expressed in.
  mark: {
    width: MARK_BOX.width,
    height: MARK_BOX.height,
    units: 'Artwork units. Every size, gap and margin in this manifest is in the same space.'
  },

  wordmark: {
    text: PROVINCE_WORDMARK,
    note: 'Fixed text. It can be shown or hidden, not edited.'
  },

  lockups: LAYOUT_ORDER.map((id) => ({
    id,
    label: LAYOUTS[id].label,
    description: LAYOUTS[id].description,
    // Where the numbers came from, so a caller knows which are measured and which are inferred.
    derivedFrom: LAYOUTS[id].source ?? null,
    fontSize: LAYOUTS[id].fontSize,
    leading: LAYOUTS[id].leading,
    showsWordmarkByDefault: LAYOUTS[id].wordmarkByDefault,
    // Vertical alignment only means something where the mark sits beside the type.
    markAlignment: LAYOUTS[id].markPlacement === 'below'
      ? null
      : { default: defaultMarkAlignment(id), options: MARK_ALIGNMENT_ORDER }
  })),

  markAlignments: MARK_ALIGNMENT_ORDER.map((id) => ({
    id,
    label: MARK_ALIGNMENTS[id].label,
    description: MARK_ALIGNMENTS[id].description
  })),

  clearSpace: CLEAR_SPACE_ORDER.map((id) => ({
    id,
    label: CLEAR_SPACE[id].label,
    // Stated both ways: the rule, and what it works out to for this mark.
    factorOfMarkWidth: CLEAR_SPACE[id].factor,
    units: CLEAR_SPACE[id].factor * MARK_BOX.width
  })),

  colours: {
    named: BRAND_COLORS,
    transparent: TRANSPARENT,
    accepts: 'A palette name, a hex value such as #006837, or any CSS colour notation. ' +
      'Values containing a quote or an angle bracket are rejected.',
    independent: ['markColor', 'textColor', 'background']
  },

  formats: EXPORT_FORMAT_ORDER.map((id) => ({
    id,
    label: EXPORT_FORMATS[id].label,
    extension: EXPORT_FORMATS[id].extension,
    mimeType: EXPORT_FORMATS[id].mimeType,
    vector: Boolean(EXPORT_FORMATS[id].vector),
    supportsTransparency: EXPORT_FORMATS[id].vector || Boolean(EXPORT_FORMATS[id].alpha),
    // Raster encoders vary by browser; the page probes for them rather than assuming.
    note: EXPORT_FORMATS[id].vector
      ? 'Vector. Text may be kept live with the font embedded, or converted to outlines.'
      : 'Raster. Rendered at one of the pixel widths below.'
  })),

  rasterWidths: SIZE_PRESETS,

  ministries: {
    reviewed: MINISTRY_LIST_REVIEWED,
    note: 'A convenience list, not an authority. Any name may be typed instead, and newlines in it ' +
      'force a line break.',
    maxLength: 200,
    groups: MINISTRY_GROUPS
  },

  // Two ways in. The compressed one is for handing a person a short link; the readable one is for
  // anything writing a configuration itself, which cannot compress but can certainly write JSON.
  configuration: {
    description: 'The lockup as a plain object. Pass it as the ' + CONFIG_PARAM + ' query ' +
      'parameter, URL-encoded, and the generator opens with those settings already applied — or ' +
      'paste it into the Configuration box on the page. Absent fields keep their current value, ' +
      'so a partial object changes only what it names.',
    parameter: CONFIG_PARAM,
    fields: Object.keys(toConfig(DEFAULTS)),
    example: toConfig(DEFAULTS),
    exampleUrl: `?${CONFIG_PARAM}=${encodeURIComponent(JSON.stringify({ lockup: 'columns', ministry: 'Ministry of Environment', markAlignment: 'top' }))}`,
    note: 'This is how to hand a lockup to someone (or something) else without describing it in ' +
      'prose. An agent that cannot run the page can still produce a link that opens it ready to ' +
      'export.'
  },

  shareLinks: {
    parameter: SHARE_PARAM,
    description: 'The same configuration compressed into one short, opaque parameter. Better for ' +
      'sending to a person; use the readable form above if you are generating it.',
    example: `?${SHARE_PARAM}=1.lz.N4IgNiBcIBYPYCcCWAvOA7ALgQwgGhAA`
  },

  agentTools: {
    standard: 'WebMCP',
    specification: 'https://webmachinelearning.github.io/webmcp/docs/proposal.html',
    description: 'Where the browser implements navigator.modelContext, this page registers tools ' +
      'for reading and setting the lockup and for exporting it, so an agent need not drive the ' +
      'controls by hand. Absent that API the page behaves normally.',
    tools: [
      'get_lockup_state', 'set_lockup', 'set_colours', 'export_lockup', 'get_share_link',
      'list_current_marks', 'find_ministry'
    ]
  }
}

const target = resolve(root, 'public/capabilities.json')

// public/ holds nothing but generated files, and git does not track an empty directory — so on a
// fresh checkout it does not exist at all and the write would fail.
mkdirSync(dirname(target), { recursive: true })
writeFileSync(target, `${JSON.stringify(manifest, null, 2)}\n`)

const bytes = JSON.stringify(manifest).length
console.log(`  capabilities      ${manifest.lockups.length} lockups, ${manifest.formats.length} formats, ` +
  `${MINISTRY_GROUPS.flatMap((group) => group.options).length} ministries  ${(bytes / 1024).toFixed(1)} KB`)
console.log('  → public/capabilities.json')
