# Campbell River / Nootka Community Health Council

This edition reconstructs the CR/N CHC emblem from the supplied 527 × 507 pixel GIF identified in the archive as the 2002 original. Open **CRN_CHC_Reconstruction.svg** in Inkscape, Illustrator, Affinity Designer or a browser. Open **CRN_CHC_Overlap_Review.html** locally for the original GIF, six selectable drawings and ink-by-ink difference maps. The viewer embeds every image it needs.

## What is editable

| Layer | Construction |
| --- | --- |
| Turquoise disc | One ellipse with a solid fill. The outer field is transparent. |
| Vancouver Island | Registered geographic polygons from the supplied GSHHS dataset. The same paths supply the grey land and the clipped white area. |
| Orca | 55 individually named paths. Expand the orca layer to edit the silhouette, pectoral fin, muzzle, eye, cheek, teeth, dorsal ribbon, shoulder and ventral hook, outer pinstripe and flukes. |
| CR/N CHC | Five drawn glyphs. All three Cs reference the same geometry. Each glyph’s halo and ink reference the same shape. |

To inspect the construction, hide the map and disc. The space between the jaws and the channels separating the four fin tips open through to the canvas. Moving a tooth exposes the actual opening underneath. Edit the C in the SVG definitions to change all three Cs at once.

## Revision record

| Saved state | Geometry decisions | Mean black, orange and cream IoU |
| --- | --- | ---: |
| Supplied drawing | Existing editable orca, map and outlined lettering. Re-rendered for this audit. | 83.0% |
| 01 Construction | Built an independent forked fin, opened the mouth in the profile, constructed eight upper and seven lower teeth, redrew the central eye shapes and lettering. | 83.5% |
| 02 Placement | Adjusted feature position, scale and shear. Larger shapes used broad, bounded displacements of existing control points. | 87.3% |
| 03 Curves | Refined the existing control net at a finer scale, including the eye, fluke ovoids and narrow outlines. | 89.0% |
| 04 Detail | Redrew upper crowns after inspection, narrowed the gum, closed the orange sliver at the shoulder, registered the map and rebuilt the illustrated white area. | 89.4% |
| 05 Master | Reshaped the terminal lobes and orange hook, strengthened the fin dividers and estimated solid colours from the GIF. Grouped the paths for editing. | 89.8% |

The GIF provided landmarks, ink samples and a comparison target. Each design change starts with authored curves or the supplied geographic data. The fitting steps adjust a fixed set of control points and transforms. The image masks serve only to measure the results. Geographic shorelines have more vertices than the orca because those paths come from geographic polygons.

## Overlap results

| Feature and measure | Supplied | Master |
| --- | ---: | ---: |
| Orca ink footprint | 91.4% | 95.2% |
| Black ink, orca | 84.9% | 92.0% |
| Orange ink, orca | 83.6% | 88.3% |
| Cream ink, orca | 80.5% | 89.2% |
| Eye, cream | 58.3% | 80.0% |
| Mouth, pale tooth crowns | 21.6% | 74.1% |
| Pectoral fin, orange | 75.5% | 89.6% |
| Lower fluke ovoid, cream | 28.6% | 55.6% |
| Lettering, black | 78.9% | 93.7% |
| White service area in the map window | 55.4% | 81.8% |

The mean two-way distance between classified orca ink boundaries fell from 0.74 to 0.41 source pixels. The 95th percentile fell from 2.24 to 1.00 pixels. These distances are measured between digital boundary pixels. They include interior openings and vary with the ink classifier.

## How to read the measurements

Intersection over union (IoU) divides the number of pixels shared by a source mask and a drawing mask by the number present in either. The three-ink mean gives black, orange and cream equal weight. All stages use identical hand-defined windows, original image coordinates and the same colour classifier. No per-feature image registration is applied at scoring time. The coastline adjustment is built into the edited artwork.

Each SVG is rendered at twice native size on white, reduced with a box filter, and compared with the GIF at native resolution. A Gaussian filter of 0.85 pixel is applied to both before classifying. An independent pale-crown test includes warm off-white teeth in the baseline. Classes with fewer than 25 reference pixels in an orca detail are left blank. Some map ink within the loose orca window can contribute to the footprint. The earlier archive used a different segmentation, so its percentages use a different scale.

Varying the smoothing width to 0.65 and 1.05 pixel gives three-ink means of 81.6% and 83.1% for the supplied drawing and 88.0% and 90.1% for the master. Fine features are especially sensitive to the choice of mask. In the final pass, the pale crowns moved from 74.3% to 74.1%, while the orca footprint increased from 94.9% to 95.2%.

## Source limits and map provenance

The number and shape of the teeth are an interpretation of the visible crowns. The gum edge, thin cream ring in the lower fluke and some narrow black-orange dividers remain uncertain. The solid palette approximates the colour of the dithered GIF. The artist’s master, ink specifications and original typeface have not been independently verified.

The complete geographic data from the supplied package are included under **geography**. The map uses an affine correction to the previous geographic fit. In withheld coastal windows the normalized land/water RMS error fell from 0.257 to 0.241. One auxiliary polygon near the shoulder was omitted from the displayed footprint because 99% of its eligible interior pixels fell on apparent water. Its original geometry remains in the accompanying geographic files. The white area follows the printed mark and is an approximate historical graphic. It has no verified jurisdictional meaning in this reconstruction.

## Re-run the audit

From the unpacked folder, run the following command with Inkscape on PATH and Python with NumPy, SciPy and Pillow installed. **audit/overlap.csv** and **audit/overlap.json** contain the supplied results. The standalone master renders identically to the final saved geometry checkpoint.

```sh
python audit/audit.py --source reference/2002.gif --out audit-rerun reference/CRN_CHC_orca_refined.svg revisions/*.svg
```

The original GIF and the input SVG are preserved under **reference**. All five reconstruction checkpoints are editable SVGs under **revisions**. The master and all checkpoints can be inspected directly without the analysis software.
