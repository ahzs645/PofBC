"""Re-run the overlap audit with Python, Pillow, NumPy, SciPy and Inkscape.
Usage: python audit.py --source source.gif --out audit-output baseline.svg pass1.svg ... final.svg
All regions are fixed in the original 527 x 507 frame. Artwork is never derived from the masks.
"""
import argparse,csv,json,subprocess,sys
from pathlib import Path
from io import BytesIO
import numpy as np
from PIL import Image,ImageDraw
from scipy.ndimage import gaussian_filter,binary_erosion,distance_transform_edt
W,H=527,507
def region(points):
 im=Image.new('L',(W,H),0);ImageDraw.Draw(im).polygon(points,fill=1);return np.asarray(im,dtype=bool)
envelope=region([(107,201),(109,173),(124,145),(152,118),(176,90),(201,73),(234,60),(267,65),(303,58),(346,58),(380,68),(407,84),(441,114),(460,148),(461,172),(453,171),(472,209),(479,249),(477,288),(463,334),(445,366),(414,396),(381,425),(338,446),(307,450),(274,440),(259,438),(244,449),(221,445),(220,437),(203,432),(201,422),(213,420),(215,420),(187,422),(158,406),(141,391),(143,381),(166,374),(198,355),(216,358),(207,341),(206,324),(212,298),(220,289),(233,298),(249,316),(261,328),(275,359),(279,366),(307,368),(335,357),(351,345),(365,320),(368,296),(361,255),(355,252),(356,266),(347,264),(353,286),(338,278),(315,259),(302,241),(292,215),(291,188),(300,161),(277,148),(270,162),(228,172),(192,186),(157,207),(142,205),(130,207),(114,206)])
mouth=region([(130,198),(140,183),(158,164),(181,149),(204,140),(212,153),(215,161),(201,168),(176,181),(152,201),(140,202),(136,202)])
def box(x0,y0,x1,y1):return region([(x0,y0),(x1,y0),(x1,y1),(x0,y1)])
fin=region([(299,151),(315,148),(329,153),(335,170),(343,190),(350,201),(355,229),(361,250),(355,251),(356,266),(349,265),(356,285),(337,276),(313,255),(299,232),(290,212),(290,192)])
letter_boxes=[(7,232,49,276),(52,233,91,276),(91,232,106,275),(109,234,149,275),(171,232,212,276),(214,233,255,275),(260,233,301,276)]
letters=np.logical_or.reduce([box(*v) for v in letter_boxes])
REG={'Orca':envelope,'Head and jaw':envelope&box(105,60,274,206),'Eye':box(191,80,255,130),'Mouth':mouth,'Pectoral fin':fin,'Dorsal and body ribbons':envelope&box(270,61,475,370)&~fin,'Tail and lower arc':envelope&box(143,290,446,448),'Upper fluke ovoid':box(235,330,264,371),'Lower fluke ovoid':box(204,375,247,408),'Lettering':letters}
# Mutually exclusive nearest swatch groups. White counts as tooth only inside the jaw window.
palette=[[(0,0,0),(56,43,36)],[(251,77,8),(155,58,25)],[(255,231,208),(234,173,141)],[(124,207,226),(86,145,154)],[(190,191,192),(123,128,129)],[(253,253,252)]]
def classes(rgb,sigma=.85):
 a=gaussian_filter(np.asarray(rgb,dtype=np.float32),(sigma,sigma,0))
 dist=[np.minimum.reduce([np.sum((a-col)**2,axis=2) for col in group]) for group in palette]
 label=np.argmin(dist,axis=0);label[(label==5)&mouth]=6
 return label
def ink(l):return (l<=2)|(l==6)
def metric(a,b,r):
 n=np.count_nonzero(a&b&r);u=np.count_nonzero((a|b)&r)
 return 100*n/u if u else None
def render(file):
 args=['inkscape',str(file),'--export-width=1054','--export-background=#ffffff','--export-background-opacity=1','--export-type=png','--export-filename=-']
 res=subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True)
 return np.asarray(Image.open(BytesIO(res.stdout)).convert('RGB').resize((W,H),Image.Resampling.BOX))
def crown(rgb,sigma=.85):
 a=gaussian_filter(np.asarray(rgb,dtype=np.float32),(sigma,sigma,0))
 return (a[:,:,0]>196)&(a[:,:,1]>183)&(a[:,:,2]>170)&(np.ptp(a,axis=2)<68)&mouth
coast_roi=region([(0,131),(58,130),(113,156),(147,153),(210,166),(271,187),(329,233),(369,276),(418,323),(473,360),(513,385),(508,442),(478,466),(425,456),(350,433),(279,400),(222,360),(158,317),(86,255),(19,210),(0,193)])&~envelope&~letters
yy,xx=np.indices((H,W))
sea_disc=((xx+.5-275)/251.6)**2+((yy+.5-253.25)/253.15)**2<.985
def audit(src,pic,sigma=.85):
 a,b=classes(src,sigma),classes(pic,sigma); rec={}
 for k,r in REG.items():
  if k=='Lettering':
   rec[k]={'black':metric(a==0,b==0,r)};continue
  fam={'ink':(ink(a),ink(b)),'black':(a==0,b==0),'orange':(a==1,b==1),'cream':(a==2,b==2)}
  if k in ('Mouth','Head and jaw','Orca'):fam['tooth white']=(a==6,b==6)
  rec[k]={name:(metric(v,w,r) if np.count_nonzero(v&r)>=25 else None) for name,(v,w) in fam.items()}
  pa=np.array([rec[k][c] for c in ('black','orange','cream')],dtype=float);rec[k]['three-ink mean']=float(np.mean(pa)) if np.all(np.isfinite(pa)) else None
 rec['Mouth']['pale crown']=metric(crown(src,sigma),crown(pic,sigma),mouth)
 rec['Map within disc']={'white service area':metric(a==5,b==5,coast_roi&sea_disc),'grey land':metric(a==4,b==4,coast_roi&sea_disc)}
 a1=ink(a);b1=ink(b);er=binary_erosion(envelope,iterations=2)
 ea=(a1^binary_erosion(a1))&er;eb=(b1^binary_erosion(b1))&er
 ds=np.r_[distance_transform_edt(~eb)[ea],distance_transform_edt(~ea)[eb]]
 rec['Orca']['ink boundary mean px']=float(ds.mean());rec['Orca']['ink boundary p95 px']=float(np.percentile(ds,95))
 return rec
def main():
 par=argparse.ArgumentParser(description=__doc__);par.add_argument('--source',type=Path,required=True);par.add_argument('--out',type=Path,required=True);par.add_argument('art',nargs='+',type=Path);args=par.parse_args();args.out.mkdir(exist_ok=True,parents=True)
 src=np.asarray(Image.open(args.source).convert('RGB'));assert src.shape==(H,W,3);out={};sensitivity={}
 for file in args.art:
  rgb=render(file);Image.fromarray(rgb).save(args.out/(file.stem+'.png'));out[file.stem]=audit(src,rgb)
  sensitivity[file.stem]={str(s):audit(src,rgb,s)['Orca']['three-ink mean'] for s in (.65,1.05)}
 (args.out/'overlap.json').write_text(json.dumps({'method':'fixed regions; native-resolution IoU; Gaussian sigma 0.85 px','stages':out,'three_ink_mean_sigma_check':sensitivity},indent=2))
 with open(args.out/'overlap.csv','w',newline='') as fx:
  w=csv.writer(fx);w.writerow(['stage','region','measure','value'])
  for n,regions in out.items():
   for k,measures in regions.items():
    for m,v in measures.items():w.writerow([n,k,m,round(v,4) if v is not None else ''])
 for n,r in out.items():
  print(n,' '.join(f'{m}={v:.2f}' for m,v in r['Orca'].items()),'lettering',round(r['Lettering']['black'],2),'mouth',round(r['Mouth']['tooth white'],2))
if __name__=='__main__':main()
